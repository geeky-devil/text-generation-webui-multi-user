# superboogav2

For a description, please see the comments in this Pull Request:

https://github.com/oobabooga/text-generation-webui/pull/3272
